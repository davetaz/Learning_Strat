Course data
===========

There are two data files, components.json and course.json which make up the content of each module.

components.json - Defines the structure, layout and text content for each module including questions.
course.json - Lists the associated resources and credits for each module, images and other media.

The contents of the data files can be viewed with a text editor and intepretted using programs such as open refine (openrefine.org).
